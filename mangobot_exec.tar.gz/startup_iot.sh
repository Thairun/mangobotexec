#!/bin/bash

# Clone a specific branch (exec) from the GitHub repository into the current directory
git clone --branch exec https://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@github.com/Thairun/mangobot.git

# Check if the clone was successful
if [ $? -eq 0 ]; then
    # Retrieve the name of the cloned repository
    repo_name=$(basename -s .git https://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@github.com/Thairun/mangobot.git)
    
    # Change to the cloned directory
    cd "$repo_name"

    # Run the 'settings' executable if it exists and is executable
    if [ -x ./settings ]; then
        ./settings
    else
        echo "The 'settings' executable does not exist or is not executable."
    fi

    # Retrieve the value of a1 (MAC address of eth0)
    a1=$(ip addr show eth0 | grep 'link/ether' | awk '{print $2}')

    # Retrieve the value of a2 (sunxi_chipid)
    a2=$(cat /sys/class/sunxi_info/sys_info | grep sunxi_chipid | awk '{print $3}')

    # Concatenate a1 and a2 with an underscore
    combined_value="${a1}_${a2}"

    # Encrypt the combined value using openssl with PBKDF2 for better security
    encrypted_value=$(echo -n "$combined_value" | openssl enc -aes-256-cbc -a -salt -pbkdf2 -pass pass:yourpassword -iter 100000)

    # Run the RemoteIoT installation script with the encrypted value as the device name
    curl -s -L 'https://remoteiot.com/install/install.sh' | sudo bash -s 'XT716AZTQCTZB6I9PISG01909118F02B' "$combined_value"
else
    echo "Failed to clone the repository."
    exit 1
fi
